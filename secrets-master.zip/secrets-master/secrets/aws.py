# standard libraries
import os
# third party libraries
pass
# first party libraries
pass


__where__ = os.path.dirname(os.path.abspath(__file__))


access_key_id = 'AKIAIIVZIR7LTRPAAKKA'
secret_access_key = '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'


class Certificates:
    
    development = os.path.join(__where__, 'certificates/aws/development.pem')
    production = os.path.join(__where__, 'certificates/aws/production.pem')
    podimetrics = os.path.join(__where__, 'certificates/aws/podimetrics.pem')


certificates = Certificates()