# standard libraries
import os
# third party libraries
pass
# first party libraries
pass


__where__ = os.path.dirname(os.path.abspath(__file__))


class Certificates:
    
    def __init__(self, directory, filename):
        self.crt = os.path.join(directory, '{}.crt'.format(filename))
        self.csr = os.path.join(directory, '{}.csr'.format(filename))
        self.key = os.path.join(directory, '{}.key'.format(filename))


directory = os.path.join(__where__, 'certificates/ssl/api')
api = Certificates(directory, 'api_podimetrics_com')
directory = os.path.join(__where__, 'certificates/ssl/www')
www = Certificates(directory, 'www_podimetrics_com')
del directory
