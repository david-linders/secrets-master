# standard libraries
import os
import urllib.parse as urlparse
# third party libraries
pass
# first party libraries
pass


__where__ = os.path.dirname(os.path.abspath(__file__))


username = 'brianjpetersen'
password = 'Computer1260@'


def encode_basic_auth(url):
    """
    >>> url = 'https://{}:{}@www.github.com'.format(
    ...     urllib.quote(username),
    ...     urllib.quote(password)
    ... )
    >>> encode_basic_auth('https://www.github.com') == url
    True
    """
    parsed_url = urlparse.urlparse(url)
    #print parsed_url.username
    if parsed_url.username is not None or parsed_url.password is not None:
        raise ValueError('URL already contains a username or password.')
    new_netloc = '{}:{}@{}'.format(
        urlparse.quote(username),
        urlparse.quote(password),
        parsed_url.netloc
    )
    new_parsed_url = (parsed_url[0], new_netloc, ) + parsed_url[2:]
    return urlparse.urlunparse(new_parsed_url)
