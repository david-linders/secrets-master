# standard libraries
import os
# third party libraries
pass
# first party libraries
pass


__where__ = os.path.dirname(os.path.abspath(__file__))


class Account:
    
    def __init__(self, username, password):
        self.username = self.user_id = username
        self.password = password


accounts = {
    'superuser': Account('superuser', 'Ulcer8ed!'),
    'weenyuser': Account('weenyuser', 'Ulcer8ed!'),
    'device_layer': Account('device_layer', 'Ulcer8ed!'),
    'demo_user': Account('demo@podimetrics.com', 'HealthyF33t!'),
}

sessions = set((
    'NUMcZ43zuKGWMC6WHZkP4Y', # device layer 
))
