# template

A template for Python projects.
